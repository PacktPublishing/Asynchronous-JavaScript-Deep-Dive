"use strict";

function genTest() {
    let x = 0;
    console.log('start');
    x++;
    console.log(x);
    x++;
    console.log(x);
    x++;
    console.log('end');
    return x;
};
