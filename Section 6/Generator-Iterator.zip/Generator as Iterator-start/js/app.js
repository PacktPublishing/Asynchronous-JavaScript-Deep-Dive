"use strict";

let arr = ['a', 'b', 'c', 'd'];




console.log("Remaining Code.");
