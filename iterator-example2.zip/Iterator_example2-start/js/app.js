"use strict";

let arr = ['a', 'b', 'c', 'd'];

let it = arr[Symbol.iterator]();

